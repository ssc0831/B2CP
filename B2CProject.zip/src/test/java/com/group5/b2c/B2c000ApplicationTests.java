package com.group5.b2c;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B2c000ApplicationTests {

	@Test
	void contextLoads() {
	}

}
